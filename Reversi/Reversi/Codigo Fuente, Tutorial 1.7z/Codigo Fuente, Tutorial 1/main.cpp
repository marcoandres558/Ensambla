//By: Marco Rodriguez B96632, Rodrigo Mendoza C04813
#include <iostream>
using namespace std;
#include "Tablero.h"
int main()
{
	Tablero tr;
}