#pragma once
#define DEBUG
#include <assert.h> /*para usar assert*/
class Tablero
{
public:
	enum Ficha {nula, blanca, negra};
	
	//construye el tablero de reversi en piosicion inicial.
	Tablero();
	/* M�todos observadores p�blicos */

	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra).
	// EFE: retorna true si la jugada en [f,c] es v�lida para la fichas del color,
	// retorna false en caso contrario.
	bool validarJugada(int f, int c, Ficha color) const;

	// EFE: retorna true si el estado actual es un estado final del juego,
	// retorna false en caso contrario.
	bool verFin() const;

	// REQ: color == blanca || color == negra.
	// EFE: retorna true si las de color no tienen opci�n para jugar,
	// false en caso contrario.
	bool verPasan(Ficha color) const;

	// REQ: 0 <= f,c <= 7.
	// EFE: retorna el valor en la fila f columna c.
	Ficha verFichaEn(int f, int c) const;

	// REQ: (0 <= f,c <= 7).
	// MOD: *this.
	// EFE: coloca en [f,c] la ficha de color.
	void colocarSimple(int f, int c, Ficha color);

	/* M�todos modificadores*/
	// REQ: (0 <= f,c <= 7) && (validarJugada(f,c,color) == true) && (color == blanca || color == negra).
	// MOD: *this.
	// EFE: coloca en [f,c] la ficha de color lo que implica realizar todos los flanqueos correspondiente
	void colocarFlanqueando(int f, int c, Ficha color);

private:
	/* M�todos observadores de flanqueo privados, se invocar�n desde "validarJugada()" */
	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra).
	// EFE: retorna true si color s� flanquea la fila f, desde [f,c]; false en caso contrario.
	bool verFlanqueaFila(int f, int c, Ficha color) const;

	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra).
	// EFE: retorna true si color s� flanquea la columna c, desde [f,c]; false en caso contrario.
	bool verFlanqueaColumna(int f, int c, Ficha color) const;

	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra).
	// EFE: retorna true si color s� flanquea la diagonal ascendente <f,c>, desde [f,c]; false en caso contrario.
	bool verFlanqueaDiagonalAscendente(int f, int c, Ficha color) const;

	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra).
	// EFE: retorna true si color s� flanquea la diagonal descendente <f,c>, desde [f,c]; false en caso contrario.
	bool verFlanqueaDiagonalDescendente(int f, int c, Ficha color) const;

	/* M�todos modificadores de flanqueo privados, se invocar�n desde "colocar()" */
	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra) && verFlanqueaFila(f,c).
	// MOD: *this.
	// EFE: flanquea la fila f, desde [f,c].
	void flanqueaFila(int f, int c, Ficha color);
	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra) && verFlanqueaColumna(f,c).
	// MOD: *this.
	// EFE: flanquea la columna c, desde [f,c].
	void flanqueaColumna(int f, int c, Ficha color);
	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra) && verFlanqueaDiagonalAscendente(f,c).
	// MOD: *this.
	// EFE: flanquea la diagonal ascendente <f,c>, desde [f,c].
	void flanqueaDiagonalAscendente(int f, int c, Ficha color);
	// REQ: (0 <= f,c <= 7) && (color == blanca || color == negra) && verFlanqueaDiagonalDescendente(f,c).
	// MOD: *this.
	// EFE: flanquea la diagonal descendente <f,c>, desde [f,c].
	void flanqueaDiagonalDescendente(int f, int c, Ficha color);

	/* REPRESENTACI�N DEL TABLERO */
	Ficha tablero[8][8];
};

Tablero::Tablero()
{

}
bool Tablero::validarJugada(int f, int c, Ficha color) const
{
	return false;
}
bool Tablero::verFin() const
{
	return false;
}
bool Tablero::verPasan(Ficha color) const
{
	return false;
}
Tablero::Ficha Tablero::verFichaEn(int f, int c) const
{
	return Ficha::blanca;
}
void Tablero::colocarSimple(int f, int c, Ficha color)
{
	assert((0 <= f) && (f <= 7));
	assert((0 <= c) && (c <= 7));
	tablero[f][c] = color;
}
void Tablero::colocarFlanqueando(int f, int c, Ficha color)
{
}
bool Tablero::verFlanqueaFila(int f, int c, Ficha color) const
{
	return false;
}
bool Tablero::verFlanqueaColumna(int f, int c, Ficha color) const
{
	return false;
}
bool Tablero::verFlanqueaDiagonalAscendente(int f, int c, Ficha color) const
{
	return false;
}
bool Tablero::verFlanqueaDiagonalDescendente(int f, int c, Ficha color) const
{
	return false;
}
void Tablero::flanqueaFila(int f, int c, Tablero::Ficha color)
{
}
void Tablero::flanqueaColumna(int f, int c, Tablero::Ficha color)
{
}
void Tablero::flanqueaDiagonalAscendente(int f, int c, Tablero::Ficha color)
{
}
void Tablero::flanqueaDiagonalDescendente(int f, int c, Tablero::Ficha color)
{

}

